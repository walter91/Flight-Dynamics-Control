function [ rad ] = deg2rad( deg )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

rad = deg*pi/180;

end

